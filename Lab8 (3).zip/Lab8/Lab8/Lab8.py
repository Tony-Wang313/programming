from os import path
import numpy as np
import math
def read_oscillatory_wave_data(filename):
    data = np.genfromtxt(filename, delimiter=",", skip_header=1)
 
    #data = np.loadtxt(filename, delimiter=',')  # Assuming CSV format
    lengths = data[:, 0]
    amplitudes = data[:, 1]
    mean_amp = np.mean(amplitudes)
    max_amp = np.max(amplitudes)
    return lengths, amplitudes, mean_amp, max_amp


def read_standing_wave_data(filename):
    data = np.genfromtxt(filename, delimiter=",", skip_header=1)
    lengths = data[:, 0]
    tensions = data[:, 1]
    speeds = np.sqrt(tensions / 1)
    return lengths, tensions, speeds


def main():
    d1 = 6
    d2 = 5
    k = 5
    shift = -1
    rows_keep = 3

    osc_file = "oscillatory_2586965.csv"
    stand_file = "standing_2586965.csv"
 

    lengths1, amplitudes, mean_amp, max_amp = read_oscillatory_wave_data(osc_file)

    print("Original oscillatory amplitudes:", amplitudes)
    print("Original mean amplitude:", mean_amp)
    print("Original max amplitude:", max_amp)

    new_amplitudes = amplitudes + shift
    new_mean_amp = np.mean(new_amplitudes)
    new_max_amp = np.max(new_amplitudes)

    print("\nShifted amplitudes:", new_amplitudes)
    print("New mean amplitude:", new_mean_amp)
    print("New max amplitude:", new_max_amp)

    lengths2, tensions, speeds = read_standing_wave_data(stand_file)

    print("\nOriginal tensions:", tensions)
    print("Original wave speeds:", speeds)

    new_tensions = tensions * k
    new_speeds = np.sqrt(new_tensions / 1)

    print("\nScaled tensions:", new_tensions)
    print("New wave speeds:", new_speeds)

    print("\nManual oscillatory check using first 3 amplitudes:")
    print("Original first 3 amplitudes:", amplitudes[:3])
    print("Shifted first 3 amplitudes:", new_amplitudes[:3])

    print("\nManual standing-wave check using first row:")
    print("First tension =", tensions[0])
    print("Scaled first tension =", new_tensions[0])
    print("First new speed =", math.sqrt(new_tensions[0]))


if __name__ == "__main__":
    main()
